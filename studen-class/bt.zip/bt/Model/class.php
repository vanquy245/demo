<?php
   include_once "../Model/ketnoi.php";
   include_once "../Model/class_con.php";
   class classs{
    protected  $tenbang;
    protected  $select;
    protected  $where;
    function __construct($t1,$t2,$t3,$t4=null)
    {
        $this->tenbang='class';
        $tam='';
        if ($t1==1) $tam=$tam.'malh,';
        if ($t2==1) $tam=$tam.'tenlop,';           
        if ($t3==1) $tam=$tam.'monhoc,';
            if ($tam=='') return;
                else $this->select=rtrim($tam,',');
        $tam='';
        $this->where='';
        if ($t4==1) $this->where='malh=';
        else
        if ($t4==2) $this->where='tenlop=';    
        else       
        if ($t4==3) $this->where='monhoc=';
    }
    public function select($t)
    { 
        if ($t==null)
            $sql='select '.$this->select.' from '.$this->tenbang;
        else $sql='select '.$this->select.' from '.$this->tenbang.' where '.$this->where."'".$t."'";
            $resulset=$this->ketnoi($sql);
            $list = [];
            while($row=mysqli_fetch_array($resulset, 1))
                {
                    if (isset($row['malh'])==false) $row['malh']=null;
                    if (isset($row['tenlop'])==false) $row['tenlop']=null;
                    if (isset($row['monhoc'])==false) $row['monhoc']=null;
                $list[]=new class_con($row['malh'],$row['tenlop'],$row['monhoc']);
                }
            return $list;
    }
    public function delete($t)
    {
        $sql='delete from '.$this->tenbang.' where '.$this->where."'".$t."'";
        $this->ketnoi($sql);
    }
    public function update($t)
    {
        $s=explode(';',$t); $tam='';
        $ss=explode(',',$this->select);
        for($i=0;$i<count($ss);$i++)
            $tam=$tam.$ss[$i].'='."'".$s[$i]."'".',';
        $sql='update '.$this->tenbang.' set '.rtrim($tam,',').' where '.$this->where."'".$s[count($s)-1]."'"; 
        echo $sql;
        $this->ketnoi($sql);
    }

    public function insert($t)
        {
            $this->ketnoi('INSERT INTO '.$this->tenbang.' ('.$this->select.') VALUES (' ."'".$t->malh."','" . $t->tenlop . "','" . $t->monhoc. "')");
        }

    public function ketnoi($sql)
        {
            $conn=ketnoi::ketnoi();
            return(mysqli_query($conn,$sql));
            mysqli_close($conn);
        }
}
   