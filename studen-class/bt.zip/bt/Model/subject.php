<?php
   include_once "../Model/ketnoi.php";
   class subjectt{
    public $masubject;
    public $tensubject;
    function __construct($masubject,$tensubject)
    {
        $this->masubject=$masubject;
        $this->tensubject=$tensubject;
    }
    static function select()
    {
        $sql="select * from subject";
        $resulset= subjectt::ketnoi($sql);
        $list =[];
        while($row=mysqli_fetch_array($resulset, 1))
            {
                $list[]=new subjectt($row['masb'],$row['tensb']);
            }
        return $list;
    }
    static function select1($masubject)
    {
        $sql="select * from subject where masb='$masubject'";
        $resulset= subjectt::ketnoi($sql);
        $list =null;
        while($row=mysqli_fetch_array($resulset, 1))
            {
                $list=new subjectt($row['masb'],$row['tensb']);
            }
        return $list;
    }
    static function insert($subject)
    {
        subjectt::ketnoi("INSERT INTO `subject`(`masb`, `tensb`) VALUES ('$subject->masubject','$subject->tensubject')");
    }
    static function delete($subject)
    {
        subjectt::ketnoi("DELETE FROM `subject` WHERE masb='$subject'");
    }
    static function timkiem($tam)
    {
      $tt="'"."%".$tam."%"."'";
       $sql = "select * from subject where masb like $tt or tensb like $tt";
       $resulset=subjectt::ketnoi($sql);
       $list = [];
       while($row=mysqli_fetch_array($resulset, 1))
           {
           $list[]=new subjectt($row['masb'],$row['tensb']);
           }
       return $list; 
    }
    static function ketnoi($sql)
        {
                $conn=ketnoi::ketnoi();
                return(mysqli_query($conn,$sql));
                mysqli_close($conn);
        }
   
   }