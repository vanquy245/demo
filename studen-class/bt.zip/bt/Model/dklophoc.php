<?php
   include_once "../Model/ketnoi.php";
   class dklophoc{
    public $masv;
    public $malh;
    function __construct($masv,$malh)
    {
        $this->masv=$masv;
        $this->malh=$malh;
    }
    static function delete($masv)
    {
        $sql="DELETE FROM `dklophoc` WHERE masv='$masv'";
        dklophoc::ketnoi($sql);
    }
    static function delete1($malh)
    {
        $sql="DELETE FROM `dklophoc` WHERE malh='$malh'";
        dklophoc::ketnoi($sql);
    }
    static function delete2($masv,$malh)
    {
        $sql="DELETE FROM `dklophoc` WHERE masv='$masv' and malh='$malh'";
        dklophoc::ketnoi($sql);
    }
    static function select($masv)
    {
        $sql="select * from dklophoc where masv='$masv'";
        $resulset= dklophoc::ketnoi($sql);
        $list = [];
        while($row=mysqli_fetch_array($resulset, 1))
            {
                $list[]=new dklophoc($row['masv'],$row['malh']);
            }
        return $list;
    }
    static function select1($malh)
    {
        $sql="select * from dklophoc where malh='$malh'";
        $resulset= dklophoc::ketnoi($sql);
        $list = [];
        while($row=mysqli_fetch_array($resulset, 1))
            {
                $list[]=new dklophoc($row['masv'],$row['malh']);
            }
        return $list;
    }
    static function select2($masv,$malh)
    {
        $sql="select * from dklophoc where masv='$masv' and malh='$malh'";
        $resulset= dklophoc::ketnoi($sql);
        $list =null;
        while($row=mysqli_fetch_array($resulset, 1))
            {
                $list=new dklophoc($row['masv'],$row['malh']);
            }
        return $list;
    }
    static function insert($masv,$malh)
    {
        dklophoc::ketnoi("INSERT INTO `dklophoc`(`masv`, `malh`) VALUES ('$masv','$malh')");
    }
    static function ketnoi($sql)
        {
                $conn=ketnoi::ketnoi();
                return(mysqli_query($conn,$sql));
                mysqli_close($conn);
        }
   }