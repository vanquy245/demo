<?php
define('HOST', 'localhost');
define('DATABASE', 'tinchi1');
define('USERNAME', 'root');
define('PASSWORD', '');
class ketnoi
{
static function ketnoi(){
    $conn=mysqli_connect(HOST, USERNAME, PASSWORD, DATABASE);
    return $conn;
}
}


