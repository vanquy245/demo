<?php
 include_once "../Model/ketnoi.php";
 include_once "../Model/students_con.php";
 class student{
  protected  $tenbang;
  protected  $select;
  protected  $where;
        function __construct($t1,$t2,$t3,$t4,$t5)
        {
            $this->tenbang='students';
            $tam='';
            if ($t1==1) $tam=$tam.'masv,';
            if ($t2==1) $tam=$tam.'tensv,';           
            if ($t3==1) $tam=$tam.'tuoi,';
            if ($t4==1) $tam=$tam.'nganh,';
                if ($tam=='') return;
                    else $this->select=rtrim($tam,',');
            $tam='';
            $this->where='';
            if ($t5==1) $this->where='masv=';
            else
            if ($t5==2) $this->where='tensv=';    
            else       
            if ($t5==3) $this->where='tuoi=';
            else       
            if ($t5==4) $this->where='nganh=';
        }
        public function select($t)
        { 
            if ($t==null)
                $sql='select '.$this->select.' from '.$this->tenbang;
            else $sql='select '.$this->select.' from '.$this->tenbang.' where '.$this->where."'".$t."'";
                $resulset=$this->ketnoi($sql);
                $list = [];
                while($row=mysqli_fetch_array($resulset, 1))
                    {
                        $list[]=new students_con($row['masv'],$row['tensv'],$row['tuoi'],$row['nganh']);
                    }
                return $list;
        }
        public function delete($t)
        {
            $sql='delete from '.$this->tenbang.' where '.$this->where."'".$t."'";
            $this->ketnoi($sql);
        }
        public function update($t)
        {
            $s=explode(';',$t); $tam='';
            $ss=explode(',',$this->select); 
            for($i=0;$i<count($ss);$i++)
                $tam=$tam.$ss[$i].'='."'".$s[$i]."'".','; 
            $sql='update '.$this->tenbang.' set '.rtrim($tam,',').' where '.$this->where."'".$s[count($s)-1]."'"; 
            $this->ketnoi($sql);
        }
        public function insert($t)
        {
            $this->ketnoi('INSERT INTO '.$this->tenbang.' ('.$this->select.') VALUES (' ."'".$t->masv."','" . $t->tensv . "','" . $t->tuoi ."','" . $t->nganh. "')");
        }


        public function ketnoi($sql)
            {
                $conn=ketnoi::ketnoi();
                return(mysqli_query($conn,$sql));
                mysqli_close($conn);
            }
    }
       
 
    