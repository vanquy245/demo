<?php
   include_once "../Model/ketnoi.php";
   class class_con{
    public $malh;
    public $tenlop;
    public $monhoc;
    function __construct($malh,$tenlop,$monhoc)
    {
        $this->malh=$malh;
        $this->tenlop=$tenlop;
        $this->monhoc=$monhoc;
    }
    static function timkiem($tam)
    {
       $conn=ketnoi::ketnoi(); $tt="'"."%".$tam."%"."'";
       $sql = "select * from class where malh like $tt or tenlop like $tt or monhoc like $tt";
       $resulset=mysqli_query($conn,$sql);
       $list = [];
       while($row=mysqli_fetch_array($resulset, 1))
           {
           $list[]=new class_con($row['malh'],$row['tenlop'],$row['monhoc']);
           }
       mysqli_close($conn);
       return $list; 
    }
   }