<?php
   include_once "../Model/ketnoi.php";
   class major{
    public $mamajor;
    public $tenmajor;
    function __construct($mamajor,$tenmajor)
    {
        $this->mamajor=$mamajor;
        $this->tenmajor=$tenmajor;
    }
    static function select()
    {
        $sql="select * from major";
        $resulset= major::ketnoi($sql);
        $list =[];
        while($row=mysqli_fetch_array($resulset, 1))
            {
                $list[]=new major($row['mamajor'],$row['tenmajor']);
            }
        return $list;
    }
    static function select1($mamajor)
    {
        $sql="select * from major where mamajor='$mamajor'";
        $resulset= major::ketnoi($sql);
        $list =null;
        while($row=mysqli_fetch_array($resulset, 1))
            {
                $list=new major($row['mamajor'],$row['tenmajor']);
            }
        return $list;
    }
    static function insert($major)
    {
        major::ketnoi("INSERT INTO `major`(`mamajor`, `tenmajor`) VALUES ('$major->mamajor','$major->tenmajor')");
    }
    static function delete($major)
    {
        major::ketnoi("DELETE FROM `major` WHERE mamajor='$major'");
    }
    static function ketnoi($sql)
        {
                $conn=ketnoi::ketnoi();
                return(mysqli_query($conn,$sql));
                mysqli_close($conn);
        }
    static function timkiem($tam)
    {
      $tt="'"."%".$tam."%"."'";
       $sql = "select * from major where mamajor like $tt or tenmajor like $tt";
       $resulset=major::ketnoi($sql);
       $list = [];
       while($row=mysqli_fetch_array($resulset, 1))
           {
           $list[]=new major($row['mamajor'],$row['tenmajor']);
           }
       return $list; 
    }
   }