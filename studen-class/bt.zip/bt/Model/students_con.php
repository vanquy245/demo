<?php
include_once "../Model/ketnoi.php";
 class students_con
 {
     public $masv;
     public $tensv;
     public $tuoi;
     public $nganh;
     function __construct($masv,$tensv,$tuoi,$nganh)
     {
         $this->masv= $masv;
         $this->tensv=$tensv;
         $this->tuoi=$tuoi;
         $this->nganh=$nganh;
     }
     static function timkiem($tam)
     {
        $conn=ketnoi::ketnoi(); $tt="'"."%".$tam."%"."'";
        $sql = "select * from students where masv like $tt or tensv like $tt or tuoi like $tt or nganh like $tt";
        $resulset=mysqli_query($conn,$sql);
        $list = [];
        while($row=mysqli_fetch_array($resulset, 1))
            {
            $list[]=new students_con($row['masv'],$row['tensv'],$row['tuoi'],$row['nganh']);
            }
        mysqli_close($conn);
        return $list; 
     }
 }