<?php
include_once "../Model/Student.php";
include_once "../Model/class.php";
include_once "../Model/students_con.php";
include_once "../Model/class_con.php";
include_once "../Controller/controller_student.php";
include_once "../Controller/controller_class.php";
include_once "../Model/dklophoc.php";
include_once "../Model/major.php";
include_once "../Model/subject.php";
include_once "../Model/students_con.php";
class tinchi
{

    static public function index($request)
    {
        try {
            //code...
            $tam=0;
            if (isset($request['t'])){
            $kt=explode('?',$request['t']); 
            $tam=$kt[0];}
            if ($tam==1) {
                            if (isset($request['timkiem'])) $list_student=students_con::timkiem($request['timkiem']);
                            else {$st= new student(1,1,1,1,2);
                                $list_student = $st->select(""); }
                                foreach($list_student as $lc)
                                {
                                 $dd[]=count(dklophoc::select($lc->masv));   
                                }
                                $list_major=major::select();
                         }
            if ($tam==2) {
                            if (isset($request['timkiem'])) $list_class=class_con::timkiem($request['timkiem']);
                            else { $cl= new classs(1,1,1);
                                    $list_class=$cl->select('');}
                            foreach($list_class as $lc)
                                    {
                                     $dd1[]=count(dklophoc::select1($lc->malh));   
                                    }
                                $list_subject=subjectt::select();
                         }
            if ($tam==3) {
                            if (isset($request['timkiem'])) $list_major=major::timkiem($request['timkiem']);
                                else  $list_major=major::select();
                                     }
            if ($tam==4) {
                            if (isset($request['timkiem'])) $list_subject=subjectt::timkiem($request['timkiem']);
                                else  $list_subject=subjectt::select();
                                     }
           
            

            include_once "../View/view.php";
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
    static public function addstudent($request)
    {
    try{
                if (!$request['masv'] || !$request['tensv'] || !$request['tuoi']|| !$request['nganh']) {
                             echo "Dữ liệu không hợp lệ";
                            return;
                         }
              $st= new student(1,1,1,1,1);
              if ($st->select($request['masv'])!=null)
                { echo "Mã sinh viên đã tồn tại"; return;}
                $studen = new students_con( $request['masv'], $request['tensv'], $request['tuoi'],$request['nganh']);
                
                $st->insert($studen);
              header("Location: students?t=1");
        }         
    catch (\Throwable){}
       
    }
    static public function addclass($request)
    {
    try{
                if (!$request['malh'] || !$request['tenlop'] || !$request['monhoc']){
                             echo "Dữ liệu không hợp lệ";
                            return;
                         }
               
                $cl= new classs(1,1,1,1);
                if ($cl->select($request['malh'])!=null)
                    { echo "Mã lớp học đã tồn tại"; return;}
                $class = new class_con( $request['malh'], $request['tenlop'], $request['monhoc']);
                $cl->insert($class);
                header("Location: students?t=2");
         }
         catch (\Throwable){}
       
    }
    static public function addmajor($request)
    {
    try{
                if (!$request['mamajor'] || !$request['tenmajor']) {
                             echo "Dữ liệu không hợp lệ";
                            return;
                         }
              if (major::select1($request['mamajor'])!=null)
                { echo "Mã ngành đã tồn tại"; return;}
                $studen = new major( $request['mamajor'], $request['tenmajor']);
                major::insert($studen);
              header("Location: students?t=3");
        }         
    catch (\Throwable){}
       
    }
    static public function addsubject($request)
    {
    try{
                if (!$request['masubject'] || !$request['tensubject']) {
                             echo "Dữ liệu không hợp lệ";
                            return;
                         }
              if (subjectt::select1($request['masubject'])!=null)
                { echo "Mã ngành đã tồn tại"; return;}
                $studen = new subjectt( $request['masubject'], $request['tensubject']);
                subjectt::insert($studen);
              header("Location: students?t=3");
        }         
    catch (\Throwable){}
       
    }


    static public function joinclass($request)
    {
        try{
            $tt=explode('?',$request['masv']);
            $sv= new student(1,1,1,1,1);
            $list_student=$sv->select($tt[0]);
                    $studen = $list_student[0];
                    $cl= new classs(1,1,1,0);
                    $d=[];
                    $list_class=$cl->select('');
                    for($i=0;$i<count($list_class);$i++)
                    {
                  
                     if (dklophoc::select2($studen->masv,$list_class[$i]->malh)==null)
                        $d[$i]=0;
                    else $d[$i]=1; 
                    }
            $tam=0;
            if (isset($tt[1])) $tam=1;
                    include_once "../View/view_dangky.php";
                    return;       
             
            }
            catch (\Throwable){}
    }
 
}
