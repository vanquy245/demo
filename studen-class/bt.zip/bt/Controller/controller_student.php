<?php
include_once "../Model/student.php";
include_once "../Model/class.php";
include_once "../Model/dklophoc.php";
include_once "../Model/students_con.php";
    class ktra_studens
    {
        static function dklophoc($request)
        {
            $t=explode('?',$request['masv']);
            dklophoc::insert($t[0],$t[1]);   
            $masv=$t[0];
            if (isset($t[2]))
                header("Location: ../public/run_students.php?masv=$masv?1");
            else  header("Location: ../public/run_students.php?masv=$masv");
                 return;
        }
        
        static function huylophoc($request)
        {
            $request1=explode('?',$request['masv']); $masv=$request1[0]; $malh=$request1[1];
            dklophoc::delete2($masv,$malh);
             header("Location: ../public/run_students.php?masv=$masv");
            return;
               
        }
        static function viewcapnhat($request)
        {
            $sv= new Student(1,1,1,1,1);
            $list_student= $sv->select($request['masv']);
            $tensv=$list_student[0]->tensv;
            $tuoi=$list_student[0]->tuoi;
            $nganh=$list_student[0]->nganh;
            include_once "../View/view_edit.php";
            return;
        }
        static function luucapnhat($request)
        {
            $sv= new Student(0,1,1,1,1);
            $sv->update($request['tensv'].';'.$request['tuoi'].';'.$request['nganh'].';'.$request['masv']);   
            header("Location: ../public/students?t=1");
            return;
        }

        static function delete_student($request)
        {
            dklophoc::delete($request['masv']);
            $sv=new student(1,1,1,1,1);
            $sv->delete($request['masv']);
            header("Location: ../public/students?t=1");
        }
        static function hienthi($request)
        {
          $sv= new student(1,1,1,1,1);
          $student=$sv->select($request['masv']);
          $list_=dklophoc::select($request['masv']);
          $lh=new classs(1,1,1,1);
          $list_class = [];
          foreach($list_ as $l)
          {
              $tam=$lh->select($l->malh);
              $list_class[]=$tam[0];
          }
          include_once "../View/view_hienthidslop.php";
                     return;
        }
      
        
    }