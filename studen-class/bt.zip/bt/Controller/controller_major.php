<?php
    include_once "../Model/major.php";
    include_once "../Model/student.php";
  class contro_major
  {
        static function danhsach($request)
        {
            $ttam=major::select1($request['mamajor']);
            $tenmajor=$ttam->tenmajor;
            $st=new student(1,1,1,1,4);
            $list_student=$st->select($tenmajor);
            include_once "../View/view_hienthi_major.php";
        }
        static function delete($request)
        {
          major::delete($request['mamajor']);
          header("Location: ../public/students?t=3");
        }
  }
?>