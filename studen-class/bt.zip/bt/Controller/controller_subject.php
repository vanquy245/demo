<?php
    include_once "../Model/subject.php";
    include_once "../Model/class.php";
  class contro_subject
  {
        static function danhsach($request)
        {
            $ttam=subjectt::select1($request['masubject']);
            $tensubject=$ttam->tensubject;
            $st=new classs(1,1,1,3);
            $list_class=$st->select($tensubject);
            include_once "../View/view_hienthi_subject.php";
        }
        static function delete($request)
        {
          subjectt::delete($request['masubject']);
          header("Location: ../public/students?t=4");
        }
  }
?>