<?php
include_once "../Model/class.php";
include_once "../Model/student.php";
    class ktra_class
    {
        static function ktra_id($id)
        {
            $list_class = classs::getlist();
            foreach($list_class as $lh)
                if ($id==$lh->malh)
                    return 0;
            return 1;
        }
        static function viewcapnhat($request)
        {
            $lh= new Classs(1,1,1,1);
            $list_class= $lh->select($request['malh']);
            $tenlop=$list_class[0]->tenlop;
            $monhoc=$list_class[0]->monhoc;
            include_once "../View/view_editclass.php";
            return;
        }
        static function luucapnhat($request)
        {
            $lh= new Classs(0,1,1,1);
            $lh->update($request['tenlop'].';'.$request['monhoc'].';'.$request['malh']);   
            header("Location: ../public/students?t=2");
            return;
        }
        static function delete_class($request)
        {
            dklophoc::delete1($request['malh']);
            $sv=new classs(1,1,1,1);
            $sv->delete($request['malh']);
            header("Location: ../public/students?t=2");
            }
            static function hienthi($request)
            {
                  $lh= new classs(1,1,1,1);
                  $class=$lh->select($request['malh']);
                  $list_=dklophoc::select1($request['malh']);
                  $sv=new student(1,1,1,1,1);
                  $list_students = [];
                  foreach($list_ as $l) 
                  {
                      $tam=$sv->select($l->masv);
                      $list_students[]=$tam[0];
                  }
                         include_once "../View/view_hienthidssinhvien.php";
                         return;
         
             }
    }