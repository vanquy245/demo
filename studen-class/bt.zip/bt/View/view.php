<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <title>List student!</title>
</head>

<body>
        <!-- Button trigger modal -->
      
   
    <button class="btn btn-primary" onclick="window.open('students?t=1?1','_self')">List student</button>
    <button class="btn btn-primary" onclick="window.open('students?t=2','_self')">List class</button>
    <button class="btn btn-primary" onclick="window.open('students?t=3','_self')">List Major</button>
    <button class="btn btn-primary" onclick="window.open('students?t=4','_self')">List Subject</button>
<?php if($tam==1){ ?>   
        
        <div class="container mt-3">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#student">
                    Add sinh viên 
                </button>
                <form method="POST" action="./students?t=1?">
                    <input name="timkiem" class="form-label" placeholder="Nhập thông tin cần tìm kiếm">
                    <button name="search" class="btn btn-primary">search</button>
                </form>
                
                <div class="modal fade" id="student" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="studentLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="./students">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="studentLabel">Add sinh viên</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                <div class="mb-3">
                                        <label class="form-label">Mã sinh viên</label>
                                        <input type="text" class="form-control" name="masv">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Tên sinh viên</label>
                                        <input type="text" class="form-control" name="tensv">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Tuổi</label>
                                        <input type="text" class="form-control" name="tuoi">
                                    </div>
                                    <div class="mb-3">
                                        <label for="major">Ngành</label>
                                        <select type="text"  class="form-control" id="major" name="nganh">
                                        <?php foreach($list_major as $major){ 
                                        ?>
                                        <option value='<?=$major->tenmajor?>'><?=$major->tenmajor?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" name="addsv">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                 <div class="col-6">
                                    <h1>List student</h1>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">Id</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Age</th>
                                                <th scope="col">Major</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    
                                            <?php $i=0;
                                             foreach ($list_student as $student) {
                                            ?>
                                            
                                            <tr>
                                                <td><?= $student->masv?></td>
                                                <td><?= $student->tensv?></td>
                                                <td><?= $student->tuoi?></td>
                                                <td><?= $student->nganh?></td>
                                                <td>
                                                <a href="../public/run_students.php?masv=<?=$student->masv ?>">
                                                        <button class="btn btn-primary">join class</button>
                                                </a>
                                                <a href="../public/run_edit.php?masv=<?=$student->masv ?>">
                                                        <button class="btn btn-primary">edit</button>
                                                </a>
                                                <a href="../public/run_hienthi.php?masv=<?=$student->masv ?>">
                                                            <button class="btn btn-info">Hiển thị</button>
                                                </a>
                                                <a href="students?masv=<?=$student->masv ?>">
                                                        <button onclick="return confirm('Số lớp đã đang ký là <?=$dd[$i]?> xác nhận xóa')" class="btn btn-info" name="delete">delete</button>
                                                       
                                                </form>
                                                </td>
                                            </tr>
                                            <?php $i++; } ?>
                                        </tbody>
                            </table>
                                
            </div>
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item">
                    <a class="page-link" href="?1" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                    </li>
                    <li class="page-item"><a class="page-link" href="?t=1?1">1</a></li>
                    <li class="page-item"><a class="page-link" href="?t=1?2">2</a></li>
                    <li class="page-item"><a class="page-link" href="?t=1?3">3</a></li>
                    <li class="page-item">
                    <a class="page-link" href="#" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                    </li>
                </ul>
                </nav>
    </div>
<?php } ?>

<?php if($tam==2){ ?>  
    <div class="container mt-3">        
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#class">
                    Add lớp học
                </button>
            <form method="POST" action="./students?t=2">
                <input name="timkiem" class="form-label" placeholder="Nhập thông tin cần tìm kiếm">
                <button name="search" class="btn btn-primary">search</button>
            </form>
                <div class="modal fade" id="class" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="studentLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="./students"> 
                                <div class="modal-header">
                                    <h5 class="modal-title" id="studentLabel">Add Lớp học</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label">Mã lớp học</label>
                                        <input type="text" class="form-control" name="malh">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Tên lớp học</label>
                                        <input type="text" class="form-control" name="tenlop">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Môn học</label>
                                        <select type="text"  class="form-control" id="major" name="monhoc">
                                        <?php foreach($list_subject as $Subject){ 
                                        ?>
                                        <option value='<?=$Subject->tensubject?>'><?=$Subject->tensubject?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" name="addlh">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

       
            <div class="col-6">
                <h1>List class</h1>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Name</th>
                            <th scope="col">Subject</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>                                                                                                           
                    <tbody>
                        <?php  $i=0;
                        foreach($list_class as $class){ 
                        ?>
                        <tr>
                            <td><?= $class->malh?></td>
                            <td><?= $class->tenlop ?></td>
                            <td><?= $class->monhoc ?></td>
                            <td>
                            <a href="../public/run_editclass.php?malh=<?=$class->malh?>">
                                    <button class="btn btn-primary">edit</button>
                             </a>
                             <form method="POST" action="./students?malh=<?=$class->malh?>"> 
                                    <button onclick="return confirm('Số sinh viên đã đang ký là <?=$dd1[$i]?> xác nhận xóa')" class="btn btn-info" name="delete1">delete</button>
                                    <button class="btn btn-info" name="hienthi1">Hiển thị</button>
                             </form>       
                            </td>
                        </tr>
                        <?php $i++; }?>
                    </tbody>
                </table>
            </div>
        </div>
<?php }?>

<?php if($tam==3){ ?>  
    <div class="container mt-3">        
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#nganh">
                    Add Ngành
                </button>
            <form method="POST" action="./students?t=3">
                <input name="timkiem" class="form-label" placeholder="Nhập thông tin cần tìm kiếm">
                <button name="search" class="btn btn-primary">search</button>
            </form>
                <div class="modal fade" id="nganh" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="studentLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="./students"> 
                                <div class="modal-header">
                                    <h5 class="modal-title" id="studentLabel">Add Ngành học</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label">Mã ngành</label>
                                        <input type="text" class="form-control" name="mamajor">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Tên ngành</label>
                                        <input type="text" class="form-control" name="tenmajor">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" name="addnganh">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

       
            <div class="col-6">
                <h1>List Major</h1>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Major</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php  foreach($list_major as $major){ 
                        ?>
                        <tr>
                            <td><?= $major->mamajor?></td>
                            <td><?= $major->tenmajor ?></td>    
                            <td>
                             <form method="POST" action="./students?mamajor=<?=$major->mamajor?>"> 
                                    <button onclick="return confirm('Số sinh viên của ngành là xác nhận xóa')" class="btn btn-info" name="delete2">delete</button>
                                    <button class="btn btn-info" name="danhsachmajor">Danh sách sinh viên của Ngành
                                    </button>
                             </form>       
                            </td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
<?php }?>

<?php if($tam==4){ ?>  
    <div class="container mt-3">        
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#subject">
                    Add Ngành
                </button>
            <form method="POST" action="./students?t=4">
                <input name="timkiem" class="form-label" placeholder="Nhập thông tin cần tìm kiếm">
                <button name="search" class="btn btn-primary">search</button>
            </form>
                <div class="modal fade" id="subject" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="studentLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="./students"> 
                                <div class="modal-header">
                                    <h5 class="modal-title" id="studentLabel">Add Subject</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label">Mã Subject</label>
                                        <input type="text" class="form-control" name="masubject">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Tên Subject</label>
                                        <input type="text" class="form-control" name="tensubject">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" name="addsubject">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

       
            <div class="col-6">
                <h1>List Subject</h1>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Subject</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=0; foreach($list_subject as $Subject){ 
                        ?>
                        <tr>
                            <td><?= $Subject->masubject?></td>
                            <td><?= $Subject->tensubject ?></td>    
                            <td>
                             <form method="POST" action="./students?masubject=<?=$Subject->masubject?>"> 
                                    <button onclick="return confirm('Số lớp đã đăng ký môn hoc là xác nhận xóa')" class="btn btn-info" name="delete3">delete</button>
                                    <button class="btn btn-info" name="danhsachsubject">Hiển thị danh sách</button>
                             </form>       
                            </td>
                        </tr>
                        <?php $i++; }?>
                    </tbody>
                </table>
            </div>
        </div>
<?php }?>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>

</html>