<?php
include_once "../Controller/controller_class.php";
$method = $_SERVER['REQUEST_METHOD'];
  switch ($method) {
      case 'GET':
        ktra_class::viewcapnhat($_REQUEST);
         return;
     case 'POST':
        ktra_class::luucapnhat($_REQUEST);
        return;
      }
