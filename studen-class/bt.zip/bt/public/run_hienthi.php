<?php
  include_once "../Controller/controller_student.php";
  $method = $_SERVER['REQUEST_METHOD'];
  switch ($method) {
    case 'GET':
        ktra_studens::hienthi($_REQUEST);
        return;
}
?>