<?php
include_once "../Controller/controller_student.php";
$method = $_SERVER['REQUEST_METHOD'];
  switch ($method) {
      case 'GET':
        ktra_studens::viewcapnhat($_REQUEST);
         return;
     case 'POST':
        ktra_studens::luucapnhat($_REQUEST);
        return;
      }
