<?php
  include_once "../Controller/controllertinchi.php";
  include_once "../Controller/controller_student.php";
  $method = $_SERVER['REQUEST_METHOD'];
  switch ($method) {
    case 'GET':
        tinchi::joinclass($_REQUEST);
        return;
    case isset($_POST['dangky']):
      ktra_studens::dklophoc($_REQUEST);
      return;
    case isset($_POST['huy']):
        ktra_studens::huylophoc($_REQUEST);
        return;
        
}
?>