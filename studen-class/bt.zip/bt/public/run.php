<?php

$url = isset($_GET['url']) ? $_GET['url'] : "";
$method = $_SERVER['REQUEST_METHOD'];
include_once "../Controller/controllertinchi.php";
include_once "../Controller/controller_student.php";
include_once "../Controller/controller_class.php";
include_once "../Controller/controller_major.php";
include_once "../Controller//controller_subject.php";
switch ($url) {
    case 'students':
        # code...
        switch ($method) {
            case 'GET':
                tinchi::index($_REQUEST);
                return;
            case isset($_POST['addsv']):
                tinchi::addstudent($_REQUEST);
                return;
            case isset($_POST['addlh']):
                tinchi::addclass($_REQUEST);
                    return;
            case isset($_POST['addnganh']):
                 tinchi::addmajor($_REQUEST);
                    return;
            case isset($_POST['addsubject']):
                tinchi::addsubject($_REQUEST);
                    return;
            case isset($_POST['delete']):
                ktra_studens::delete_student($_REQUEST);
                return;
            case isset($_POST['delete1']):
                ktra_class::delete_class($_REQUEST);
                    return;
            case isset($_POST['delete2']):
                contro_major::delete($_REQUEST);
                    return;
            case isset($_POST['delete3']):
                contro_subject::delete($_REQUEST);
                    return;
            case isset($_POST['hienthi1']):
                ktra_class::hienthi($_REQUEST);
                return;
            case isset($_POST['danhsachmajor']):
                contro_major::danhsach($_REQUEST);
                return;
            case isset($_POST['danhsachsubject']):
                contro_subject::danhsach($_REQUEST);
                    return;
            case isset($_POST['search']):
              tinchi::index($_REQUEST);
                    return;
        }
}